

<?php
/*
This is for the basic PHP program ran locally using FreeCodeCamps tutorial.
This is a basic "Hello World" type program
*/
echo "Hello HireScore!" . PHP_EOL;
?>